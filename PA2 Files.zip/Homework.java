
/*
 * COP 3330 Summer 2025
 * Student Name: TODO_your_name_here
 * 
 * This file contains the three classes you need to complete.
 * Only add your code below the TODO comments.
 * Do not modify any other parts of this file.
 */

class Utility {
    
    // TODO: Complete the Utility class
    
    
}


class StudentList extends BaseList  {
    
    // TODO: Complete the StudentList class


}


class CourseList extends BaseList {
    
    // TODO: Complete the CourseList class
    
    
}
